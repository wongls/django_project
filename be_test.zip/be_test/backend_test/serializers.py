from django.contrib.auth.models import User, Group
from backend_test.models import test_user
from rest_framework import serializers


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ('url', 'username', 'email', 'groups')


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ('url', 'name')
		
class BuildingSerializer(serializers.ModelSerializer):
    class Meta:
       model = test_user
    
       fields = ('id', 'user_name', 'profile_type')