from django.shortcuts import render

# Create your views here.

from django.contrib.auth.models import User, Group
from backend_test.models import test_user
from rest_framework import viewsets
from backend_test.serializers import UserSerializer, GroupSerializer, BuildingSerializer
from backend_test.get_profile_script import *
from backend_test.models import test_user
	
class TestUserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = test_user.objects.all()
    serializer_class = BuildingSerializer

	#This is to get parameter from url specified by user, currently it is looking
	#at username field
    def get_queryset(self):       
       ws_user_name = self.request.GET.get('user_name')
       ws_savings_amt = self.request.GET.get('savings')
       ws_loan_amt = self.request.GET.get('loan')
	   
	   #if parameter "user_name" is avaiable in url
       if not ws_user_name:
	       ret_queryset = test_user.objects.all().filter()
       else:
            find_queryset = test_user.objects.all().filter(user_name=ws_user_name)
            
            # found in database
            if len(find_queryset) != 0:
               ret_queryset = get_profile_class.get_profile(find_queryset, ws_user_name)
            else:   
               # not found in database
               if not ws_savings_amt:
                  ws_savings_amt = 0
               if not ws_loan_amt:
                  ws_loan_amt = 0	
               ws_profile_type=""	
               ws_saving_score = 0
               ws_loan_score = 0
			   
			   #Saving amount scoring
               if (int(ws_savings_amt) > 0 and int(ws_savings_amt) <= 2000): 
                   ws_saving_score = 1;

               if (int(ws_savings_amt) > 2000 and int(ws_savings_amt) <= 4000): 
                  ws_saving_score = 2;
               
               if (int(ws_savings_amt) > 4000 and int(ws_savings_amt) <= 6000): 
                  ws_saving_score = 3;
               
               if (int(ws_savings_amt) > 6000 and int(ws_savings_amt) <= 8000): 
                  ws_saving_score = 4;
               
               if (int(ws_savings_amt) > 8000 and int(ws_savings_amt) <= 10000): 
                  ws_saving_score = 5;
			   
               #loan amount scoring
               if (int(ws_loan_amt) > 0 and int(ws_loan_amt) <= 2000): 
                   ws_loan_score = 5;
               
               if (int(ws_loan_amt) > 2000 and int(ws_loan_amt) <= 4000): 
                  ws_loan_score = 4;
               
               if (int(ws_loan_amt) > 4000 and int(ws_loan_amt) <= 6000):
                  ws_loan_score = 3;
               
               if (int(ws_loan_amt) > 6000 and int(ws_loan_amt) <= 8000): 
                  ws_loan_score = 2;
               
               if (int(ws_loan_amt) > 8000 and int(ws_loan_amt) <= 10000): 
                  ws_loan_score = 1;
               
              
               #Profile type derivation
               ws_total_score = ws_saving_score + ws_loan_score
			   
               if (ws_total_score >= 2 and ws_total_score < 4): 
                  ws_profile_type = "D";
               
               if (ws_total_score >= 4 and ws_total_score < 6): 
                  ws_profile_type = "C";
               
               if (ws_total_score >= 6 and ws_total_score < 8): 
                  ws_profile_type = "B";
               
               if (ws_total_score >= 8):
                  ws_profile_type = "A"
			   
               #Add record to test_user table
               add_queryset = test_user(user_name=ws_user_name, question_group='1', profile_type=ws_profile_type)  
               add_queryset.save()
               ret_queryset = get_profile_class.get_profile(find_queryset, ws_user_name)
            		
       return ret_queryset
	   
class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer

	#This is to get parameter from url specified by user, currently it is looking
	#at username field
    def get_queryset(self):
       ret_queryset = User.objects.all().filter()
       another_param = another_param = self.request.GET.get('username')

       if another_param:
            ret_queryset = get_profile_class.get_profile(ret_queryset, another_param)
			
       return ret_queryset


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
	
	
	
