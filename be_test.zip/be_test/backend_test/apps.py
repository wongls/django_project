from django.apps import AppConfig


class BackendTestConfig(AppConfig):
    name = 'backend_test'
