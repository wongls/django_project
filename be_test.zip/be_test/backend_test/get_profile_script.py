
class get_profile_class:
   def __init__(self, *args, **kwargs):  
      print("Hello from get_profile_class")
   def get_profile(queryset, para_user_name):
      print("Hello from get_profile function")
      queryset = queryset.filter(user_name=para_user_name)
      return queryset 