from django.db import models

# Create your models here.

class test_user(models.Model):
   user_name= models.CharField(max_length=50)
   question_group= models.CharField(max_length=10)
   profile_type= models.CharField(max_length=10)