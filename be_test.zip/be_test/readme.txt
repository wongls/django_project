
1. Download and unzip the file.
2. Run it with below command
   python be_test\manage.py runserver
3. Launch internet browser and type http://127.0.0.1:8000/test_user/?&loan=<loan amount>&savings=<saving amount>&user_name=<user name>
   <loan amount> and <saving amount> can be 2000, 4000, 6000, 8000, and 10000.
   <user name> any name, if existed, it will show up from database, else it will add in database